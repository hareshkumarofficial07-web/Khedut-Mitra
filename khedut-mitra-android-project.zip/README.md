# ખેડૂત મિત્ર – Android પ્રોજેક્ટ

ગુજરાતના ખેડૂતો માટે ગુજરાતી ભાષાનું Android starter app.

## Android Studio માં APK બનાવવાની રીત
1. Android Studio (Hedgehog અથવા નવું) ઇન્સ્ટોલ કરો.
2. આ ZIP extract કરો.
3. Android Studio માં `khedut-mitra-android` ફોલ્ડર Open કરો.
4. Gradle sync પૂર્ણ થવા દો.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) પસંદ કરો.
6. APK સામાન્ય રીતે `app/build/outputs/apk/debug/app-debug.apk` માં મળશે.

## હાલ શું કાર્ય કરે છે
- ગુજરાતી હોમ સ્ક્રીન
- ગુજરાતના 33 જિલ્લાની પસંદગી
- ઉત્પાદન કેટેગરી અને શોધ
- ડેમો કાર્ટ
- ખેતી માર્ગદર્શનનાં સામાન્ય લેખ
- વેપારી નોંધણીનું સ્થાનિક ડેમો ફોર્મ

## હજી શું જોડવાનું બાકી છે
આ પ્રોજેક્ટ production-ready marketplace નથી. વાસ્તવિક ગ્રાહક/વેપારી login, database, product upload, stock, verified pricing, orders, payment gateway, delivery, admin approval, notifications અને privacy/terms માટે backend તથા સુરક્ષા કામ જરૂરી છે. હાલની વસ્તુઓ ઉદાહરણરૂપ છે; કોઈ વેચાણ કે ઉપલબ્ધ સ્ટોકની ખાતરી નથી.

ખાતર અને પાક સંરક્ષણ દવાઓનું વેચાણ લાગુ લાઇસન્સ અને કાયદાકીય નિયમોનું પાલન કરીને જ કરવું.
