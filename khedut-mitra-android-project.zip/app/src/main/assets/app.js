const districts=["અમદાવાદ","અમરેલી","આણંદ","અરવલ્લી","બનાસકાંઠા","ભરૂચ","ભાવનગર","બોટાદ","છોટા ઉદેપુર","દાહોદ","દેવભૂમિ દ્વારકા","ડાંગ","ગાંધીનગર","ગીર સોમનાથ","જામનગર","જૂનાગઢ","કચ્છ","ખેડા","મહિસાગર","મહેસાણા","મોરબી","નર્મદા","નવસારી","પંચમહાલ","પાટણ","પોરબંદર","રાજકોટ","સાબરકાંઠા","સુરત","સુરેન્દ્રનગર","તાપી","વડોદરા","વલસાડ"];
const products=[
{n:"સામાન્ય NPK ખાતર",c:"ખાતર",i:"🧪",d:"પાકની પોષક જરૂરિયાત માટે વિવિધ ગ્રેડ ઉપલબ્ધ હોઈ શકે છે."},
{n:"જીવામૃત / ઓર્ગેનિક ઇનપુટ",c:"ખાતર",i:"🌿",d:"જૈવિક ખેતી માટેના ઇનપુટ વિશે માહિતી."},
{n:"કપાસનું બિયારણ",c:"બિયારણ",i:"🌱",d:"વાવણી પહેલાં જાત અને વિસ્તારની ભલામણ તપાસો."},
{n:"જીરું બિયારણ",c:"બિયારણ",i:"🌾",d:"સ્થાનિક હવામાન અને વાવણી સમય ધ્યાનમાં લો."},
{n:"પાક સંરક્ષણ ઉત્પાદન",c:"પાક સંરક્ષણ",i:"🛡️",d:"ઉપયોગ પહેલાં લેબલ અને અધિકૃત સલાહ વાંચો."},
{n:"સ્પ્રેયર પંપ",c:"સાધનો",i:"🚿",d:"ખેતરમાં છંટકાવ માટેનું સાધન."},
{n:"ડ્રિપ સિંચાઈ કિટ",c:"સાધનો",i:"💧",d:"પાણી બચત માટે સિંચાઈ સાધન."},
{n:"ખેતીનાં હેન્ડ ટૂલ્સ",c:"સાધનો",i:"🛠️",d:"દૈનિક ખેતી કામ માટેનાં સાધનો."}
];
let category="બધું",cart=[];
const $=s=>document.querySelector(s);
function render(){
 const q=$("#search").value.trim().toLowerCase();
 const arr=products.filter(p=>(category==="બધું"||p.c===category)&&(!q||(p.n+" "+p.c+" "+p.d).toLowerCase().includes(q)));
 $("#resultCount").textContent=arr.length+" વસ્તુઓ";
 $("#products").innerHTML=arr.map((p)=>`<article class="product"><div class="pimage">${p.i}</div><small>${p.c}</small><b>${p.n}</b><p>${p.d}</p><button onclick="addCart('${p.n.replace(/'/g,"")}')">કાર્ટમાં ઉમેરો</button></article>`).join("")||"<p>મળ્યું નથી. બીજો શબ્દ શોધો.</p>";
}
document.querySelectorAll(".cat").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".cat").forEach(x=>x.classList.remove("active"));b.classList.add("active");category=b.dataset.cat;render()}));
$("#search").addEventListener("input",render);
$("#districtBtn").onclick=()=>{openModal(`<h2>તમારો જિલ્લો પસંદ કરો</h2><p>જિલ્લો પસંદ કરવાથી સ્થાનિક માહિતી બતાવવાની સુવિધા આગળ ઉમેરાશે.</p><select id="districtSelect" style="width:100%;padding:12px;border:1px solid #dce7d9;border-radius:10px">${districts.map(d=>`<option>${d}</option>`).join("")}</select><br><br><button class="action" onclick="setDistrict()">પસંદ કરો</button>`)};
function setDistrict(){let d=$("#districtSelect").value;$("#districtBtn").textContent="📍 "+d+" ▾";closeModal()}
function addCart(n){cart.push(n);$("#cartCount").textContent=cart.length;toast("કાર્ટમાં ઉમેર્યું")}
function showCart(){openModal(`<h2>તમારું કાર્ટ (${cart.length})</h2>${cart.length?cart.map((x,i)=>`<p>${i+1}. ${x}</p>`).join(""):"<p>તમારું કાર્ટ ખાલી છે.</p>"}<p>આ પ્રોટોટાઇપમાં હજી ઓર્ડર/ચુકવણી સક્રિય નથી.</p>`)}
function showGuide(topic){const data={"માટી પરીક્ષણ":"ખેતરની જમીનનું માટી પરીક્ષણ કરાવી pH અને પોષક તત્ત્વો જાણો. પરિણામ મુજબ સ્થાનિક કૃષિ નિષ્ણાતની સલાહથી ખાતર આપો.","પાણી વ્યવસ્થાપન":"પાકની જરૂરિયાત અને જમીન પ્રમાણે સિંચાઈ કરો. શક્ય હોય ત્યાં ટપક સિંચાઈ અને મલ્ચિંગથી પાણી બચાવો.","પાક ફેરબદલી":"એક જ ખેતરમાં સતત એક જ પાક લેવાને બદલે યોગ્ય પાક ફેરબદલી અપનાવો. સ્થાનિક કૃષિ યુનિવર્સિટીનું માર્ગદર્શન લો.","સલામત છંટકાવ":"દવા વાપરતા પહેલાં લેબલ વાંચો, યોગ્ય સુરક્ષા સાધનો પહેરો અને પવનની દિશા ધ્યાનમાં રાખો. માત્ર અધિકૃત ભલામણ મુજબ જ ઉપયોગ કરો."};openModal(`<h2>${topic}</h2><p>${data[topic]}</p><p><b>નોંધ:</b> પાક, જમીન અને વિસ્તાર પ્રમાણે સલાહ બદલાઈ શકે છે. ચોક્કસ માર્ગદર્શન માટે નજીકના કૃષિ વિજ્ઞાન કેન્દ્રનો સંપર્ક કરો.</p>`)}
function sellerSubmit(){let n=$("#sellerName").value.trim(),p=$("#sellerPhone").value.trim();if(!n||!/^[0-9]{10}$/.test(p)){toast("નામ અને 10 અંકનો મોબાઇલ નંબર દાખલ કરો");return}$("#sellerMsg").textContent="ડેમો નોંધણી તૈયાર: "+n+" ("+p+"). આ માહિતી સર્વર પર મોકલાઈ નથી.";toast("ડેમો નોંધણી તૈયાર")}
function openModal(html){$("#modalContent").innerHTML=html;$("#modal").classList.add("open")}
function closeModal(){$("#modal").classList.remove("open")}
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
function toast(msg){let t=document.createElement("div");t.textContent=msg;t.style="position:fixed;bottom:90px;left:50%;transform:translateX(-50%);background:#173b25;color:white;padding:11px 16px;border-radius:20px;font-size:12px;z-index:20";document.body.appendChild(t);setTimeout(()=>t.remove(),1800)}
render();